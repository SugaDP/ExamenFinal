from sqlalchemy import Column, Integer, String, Date, ForeignKey
from sqlalchemy.orm import relationship
from persistence.base import Base

class DetalleCliente(Base):
    __tablename__ = 'detalle_clientes'
    
    id_detalle = Column(Integer, primary_key=True)
    id_cliente = Column(Integer, ForeignKey('clientes.id_clientes'), unique=True)
    documento_identidad = Column(String(50))
    fecha_registro = Column(Date)

    clientes = relationship("Clientes", back_populates="detalle")
