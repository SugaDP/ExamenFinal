from sqlalchemy import Column, Integer, String, DECIMAL
from sqlalchemy.orm import relationship
from persistence.base import Base

class Membresia(Base):
    __tablename__ = 'membresias'
    
    id_membresia = Column(Integer, primary_key=True)
    tipo = Column(String(50))
    precio = Column(DECIMAL(6, 2))

    clientes = relationship("Clientes", back_populates="membresia")
