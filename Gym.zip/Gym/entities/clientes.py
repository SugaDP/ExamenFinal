from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from persistence.base import Base

from entities.membresia import Membresia
from entities.detalle_cliente import DetalleCliente
from entities.rutina import Rutina

class Clientes(Base):
    __tablename__ = 'clientes'
    
    id_clientes = Column(Integer, primary_key=True, autoincrement=True) 
    nombre = Column(String(50))
    correo = Column(String(60), unique=True)
    telefono = Column(String(15))
    id_membresia = Column(Integer, ForeignKey('membresias.id_membresia')) #1:N

    membresia = relationship(Membresia, back_populates="clientes")
    detalle = relationship(DetalleCliente, uselist=False, back_populates="clientes") # 1;1
    rutinas = relationship("Rutina", secondary="clientes_rutina", back_populates="clientes") #N:N
