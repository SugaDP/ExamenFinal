# entities/__init__.py
# Este archivo permite que la carpeta 'entities' sea un paquete de Python

# Import models in order of dependency
from entities.entrenador import Entrenador
from entities.membresia import Membresia
from entities.detalle_cliente import DetalleCliente
# Import the association table first
from entities.clientes_rutina import clientes_rutina
# Then import the models that use the association table
from entities.rutina import Rutina
from entities.clientes import Clientes
