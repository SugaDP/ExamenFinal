from sqlalchemy import Table, Column, Integer, ForeignKey
from persistence.base import Base

cliente_rutina = Table(
    'clientes_rutina', Base.metadata,
    Column('id_clientes', Integer, ForeignKey('clientes.id_clientes'), primary_key=True),
    Column('id_rutina', Integer, ForeignKey('rutinas.id_rutina'), primary_key=True)
)
