from sqlalchemy import Column, Integer, ForeignKey, Table
from persistence.base import Base

# Tabla intermedia para la relación N:N entre clientes y rutinas
clientes_rutina = Table(
    'clientes_rutina',
    Base.metadata,
    Column('id_clientes', Integer, ForeignKey('clientes.id_clientes'), primary_key=True),
    Column('id_rutinas', Integer, ForeignKey('rutinas.id_rutina'), primary_key=True)
)
