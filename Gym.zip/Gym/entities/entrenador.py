from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from persistence.base import Base

class Entrenador(Base):
    __tablename__ = 'entrenadores'
    
    id_entrenador = Column(Integer, primary_key=True)
    nombre = Column(String(50))
    especialidad = Column(String(50))

    rutinas = relationship("Rutina", back_populates="entrenador")
