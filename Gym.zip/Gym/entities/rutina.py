from sqlalchemy import Column, Integer, String, Text, ForeignKey
from sqlalchemy.orm import relationship
from persistence.base import Base

class Rutina(Base):
    __tablename__ = 'rutinas'
    
    id_rutina = Column(Integer, primary_key=True)
    nombre = Column(String(50))
    descripcion = Column(Text)
    id_entrenador = Column(Integer, ForeignKey('entrenadores.id_entrenador'))

    entrenador = relationship("Entrenador", back_populates="rutinas")
    clientes = relationship("Clientes", secondary="clientes_rutina", back_populates="rutinas")
