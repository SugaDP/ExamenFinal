
from entities.clientes import Clientes
from entities.membresia import Membresia # Necesaria para la relación al mostrar clientes
from persistence.db import Session


def get_clientes():
    session = Session()
    try:
        clientes = session.query(Clientes).all()
        if not clientes:
            print("\n--- No hay clientes r  egistrados. ---")
            return
        print("\n--- Listado de Clientes ---")
        for c in clientes:
            membresia_tipo = c.membresia.tipo if c.membresia else "Sin membresía"
            print(f"ID: {c.id_clientes} | Nombre: {c.nombre} | Tel: {c.telefono} | Correo: {c.correo} | Membresía: {membresia_tipo}")
        print("---------------------------")
    finally:
        session.close()

def save_cliente(nombre, correo, telefono, id_membresia):
    session = Session()
    try:
        nuevo = Clientes(nombre=nombre, correo=correo, telefono=telefono, id_membresia=id_membresia)
        session.add(nuevo)
        session.commit()
        print(f"\n--- Cliente '{nuevo.nombre}' agregado exitosamente. ---")
    except Exception as e:
        session.rollback()
        print(f"\n--- Error al agregar cliente: {e} ---")
    finally:
        session.close()

def update_cliente(id_cliente_actualizar, nombre_nuevo, correo_nuevo, telefono_nuevo, id_membresia_nueva):
    session = Session()
    try:
        cliente_existente = session.query(Clientes).filter_by(id_clientes=id_cliente_actualizar).first()
        if cliente_existente:
            cliente_existente.nombre = nombre_nuevo
            cliente_existente.correo = correo_nuevo
            cliente_existente.telefono = telefono_nuevo
            cliente_existente.id_membresia = id_membresia_nueva
            session.commit()
            print(f"\n--- Cliente ID {id_cliente_actualizar} actualizado a '{cliente_existente.nombre}'. ---")
        else:
            print(f"\n--- Cliente con ID {id_cliente_actualizar} no encontrado. ---")
    except Exception as e:
        session.rollback()
        print(f"\n--- Error al actualizar cliente: {e} ---")
    finally:
        session.close()

def delete_cliente(id_cliente_eliminar):
    session = Session()
    try:
        cliente_existente = session.query(Clientes).filter_by(id_clientes=id_cliente_eliminar).first()
        if cliente_existente:
            nombre_cliente = cliente_existente.nombre
            session.delete(cliente_existente)
            session.commit()
            print(f"\n--- Cliente '{nombre_cliente}' (ID: {id_cliente_eliminar}) eliminado exitosamente. ---")
        else:
            print(f"\n--- Cliente con ID {id_cliente_eliminar} no encontrado. ---")
    except Exception as e:
        session.rollback()
        print(f"\n--- Error al eliminar cliente: {e} ---")
    finally:
        session.close()

# --- Lógica principal del menú ---

if __name__ == "__main__":
    while True:
        print("\n")
        print("-----------------------------------")
        print("    MENÚ CRUD DE CLIENTES DEL GYM  ")
        print("-----------------------------------")
        print("1. Ver todos los Clientes")
        print("2. Agregar nuevo Cliente")
        print("3. Actualizar Cliente existente")
        print("4. Eliminar Cliente existente")
        print("0. Salir")
        print("-----------------------------------")

        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            get_clientes()
        elif opcion == '2':
            print("\n--- Agregar Nuevo Cliente ---")
            nombre = input("Nombre: ")
            correo = input("Correo: ")
            telefono = input("Teléfono: ")
            id_membresia = input("ID de Membresía: ")
            try:
                save_cliente(nombre, correo, telefono, int(id_membresia))
            except ValueError:
                print("Error: El ID de Membresía debe ser un número entero.")
        elif opcion == '3':
            print("\n--- Actualizar Cliente ---")
            id_cliente = input("ID del cliente a actualizar: ")
            try:
                id_cliente = int(id_cliente)
                nombre = input("Nuevo nombre: ")
                correo = input("Nuevo correo: ")
                telefono = input("Nuevo teléfono: ")
                id_membresia = input("Nuevo ID de Membresía: ")
                update_cliente(id_cliente, nombre, correo, telefono, int(id_membresia))
            except ValueError:
                print("Error: ID de Cliente y Membresía deben ser números enteros.")
        elif opcion == '4':
            print("\n--- Eliminar Cliente ---")
            id_cliente = input("ID del cliente a eliminar: ")
            try:
                delete_cliente(int(id_cliente))
            except ValueError:
                print("Error: El ID de Cliente debe ser un número entero.")
        elif opcion == '0':
            print("\nSaliendo del programa. ¡Adiós!")
            break
        else:
            print("Opción no válida. Por favor, intente de nuevo.")