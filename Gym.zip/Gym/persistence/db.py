from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from persistence.base import Base

import entities

engine = create_engine("mysql+mysqlconnector://root:adminadmin@localhost/GestionGym", echo=True)

Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
