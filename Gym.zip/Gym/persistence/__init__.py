# entities/__init__.py
# Este archivo permite que la carpeta 'entities' sea un paquete de Python
